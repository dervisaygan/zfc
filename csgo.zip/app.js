const puppeteer = require('puppeteer-extra')
const { executablePath } = require('puppeteer')
const StealthPlugin = require('puppeteer-extra-plugin-stealth')
puppeteer.use(StealthPlugin())
const express = require('express')
const app = express()

app.get('/', (req, res) => {
  res.send({ title: 'Başarılı!' })
})


var time = 0
var pages = 0
const zfc = () => {
  return new Promise(async (resolve, reject) => {
    const browser = await puppeteer.launch({
      args: [
        '--disable-gpu',
        '--disable-dev-shm-usage',
        '--disable-setuid-sandbox',
        '--no-first-run',
        '--no-sandbox',
        '--no-zygote',
        '--single-process',
      ],
      executablePath: executablePath(),
      userDataDir: './asd',
    });
    const page = await browser.newPage();
    await page.goto('https://onlinealarmkur.com/stopwatch/');
    await page.click('#start');
    setInterval(async () => {
      const links = await page.evaluate(() => {
        var m = document.querySelector('#elapsed-time-container').textContent
        return m
      });
      pages = links
    }, 1000);
  })
}




zfc()
  .then(res => {
    console.log(res);
  })
  .catch(err=>{
    console.log(err);
  })

setInterval(() => {
  time++
}, 1000);



app.get('/zfc', async (req, res) => {

  res.send({
    time: time,
    pages: pages
  })
})


app.listen(80)

