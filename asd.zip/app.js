const express = require('express')
const app = express()


app.get('/zfc',(req,res)=>{
    res.send({
        status:true,
        data:'İşlem başarılı'
    })
})
const asd = ()=>{
    setInterval(() => {
        console.log(new Date().toLocaleString());
    }, 1000);
}
app.get('/',(req,res)=>{
    asd()
    res.send({
        status:true,
        data:'İşlem başarılı'
    })
})

var port =80 || process.env.PORT


app.listen(port,()=>{
console.log(`Sunucu ${port} portunda ayakta`);
})