const express = require('express')
const app = express()
const whoiser = require('whoiser')

app.use(function (req, res, next) {
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
    res.setHeader('Access-Control-Allow-Credentials', true);
    next();
});



app.get('/', (req, res) => {
    res.send({
        status: true,
        message: 'Proje çalışıyor...'
    })
})


app.get('/:domain', async (req, res) => {
    try {
        var params = req.params.domain
        whoiser(params)
            .then(resp => {
                resp.status = true
                res.send(resp)
            })
            .catch(err => {
                res.send({
                    status: false
                })
            })
    } catch (err) {
        res.send({
            status: false
        })
    }
})



app.listen(process.env.PORT || 3000, () => {
    console.log('Success');
})